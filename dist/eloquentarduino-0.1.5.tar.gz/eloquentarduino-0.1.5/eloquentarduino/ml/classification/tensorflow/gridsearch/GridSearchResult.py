from eloquentarduino.ml.classification.abstract.GridSearchResult import GridSearchResult as Base


class GridSearchResult(Base):
    pass