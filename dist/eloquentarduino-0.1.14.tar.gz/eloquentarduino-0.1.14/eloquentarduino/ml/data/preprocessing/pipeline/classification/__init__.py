from eloquentarduino.ml.data.preprocessing.pipeline.classification.Cascading import Cascading
from eloquentarduino.ml.data.preprocessing.pipeline.classification.Classify import Classify
from eloquentarduino.ml.data.preprocessing.pipeline.classification.InRow import InRow
from eloquentarduino.ml.data.preprocessing.pipeline.classification.SmoothClassification import SmoothClassification