from eloquentarduino.ml.data.preprocessing.pipeline.BaseStep import BaseStep


class Window(BaseStep):
    pass