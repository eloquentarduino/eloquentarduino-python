from eloquentarduino.ml.metrics.device.Resources import Resources
from eloquentarduino.ml.metrics.device.Runtime import Runtime