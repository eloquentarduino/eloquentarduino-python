import re

import pandas as pd
from micromlgen import port
from time import sleep

from eloquentarduino.ml.metrics.plot import Barplot
from eloquentarduino.utils import jinja


class Runtime:
    """
    Compute on-device inference time and accuracy
    """
    def __init__(self, project):
        """
        :param project:
        """
        self.project = project
        self.results = []

    @property
    def df(self):
        """
        Convert results to DataFrame
        :return: pd.DataFrame
        """
        data = [{
            'dataset': r['dataset'],
            'clf': r['clf'],
            'score': r['score'],
            'time': r['time']
        } for r in self.results]

        return pd.DataFrame(data, columns=['dataset', 'clf', 'score', 'time'])

    def benchmark(self, dataset_name, classifiers, X_test, y_test, X_train=None, y_train=None, repeat=1):
        """
        Benchmark given classifiers
        :param dataset_name:
        :param classifiers:
        :param X_test:
        :param y_test:
        :param X_train:
        :param y_train:
        :return: list of benchmark results
        """
        assert X_train is None and y_train is None or X_train is not None and y_train is not None, "X_train and y_train MUST be both None or not None"
        assert X_test is not None and y_test is not None, "X_test and y_test MUST be both not None"

        with self.project.tmp_project() as tmp:
            # load inference time benchmarking sketch
            sketch = jinja('metrics/Runtime.jinja', {
                'X_test': X_test,
                'y_test': y_test,
                'TEST_SAMPLES': len(y_test),
                'TEST_TIMES': repeat
            })
            tmp.files.add('%s.ino' % tmp.name, contents=sketch, exists_ok=True)

            for name, clf in classifiers:
                if X_train is not None:
                    clf.fit(X_train, y_train)

                self.benchmark_one(tmp, dataset_name, name, clf)

        return self.results

    def benchmark_one(self, project, label, clf_name, clf):
        """
        Benchmark a single classifier
        :param project:
        :param label:
        :param clf_name:
        :param clf:
        :return:
        """
        ported = port(clf, classname='Classifier')

        project.files.add('Classifier.h', contents=ported, exists_ok=True)
        project.upload(verbose=False)
        sleep(1)

        response = project.serial.read_until('======', timeout=10)
        match = re.search(r'inference time = ([0-9.]+) micros[\s\S]+?Score = ([0-9.]+)', response)

        if match is not None:
            self.results.append({
                'dataset': label,
                'clf': clf_name,
                'time': float(match.group(1)),
                'score': float(match.group(2))
            })
        else:
            self.project.log('Failed to parse response: %s' % response)

    def plot(self, metric, sort=True, scale='linear', **kwargs):
        """
        Plot given metric
        :param metric:
        :param sort:
        :return:
        """
        assert metric in self.df.columns and metric != 'clf', 'metric MUST be one of the columns'

        Barplot(self.df, x='clf', y=metric, sort=sort, scale=scale, **kwargs)