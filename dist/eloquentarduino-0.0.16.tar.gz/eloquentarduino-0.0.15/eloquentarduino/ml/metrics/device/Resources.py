import re

import pandas as pd
from micromlgen import port

from eloquentarduino.ml.metrics.plot import Barplot
from eloquentarduino.utils import jinja


class Resources:
    """
    Compute on-device metrics
    """
    def __init__(self, project):
        """
        :param project:
        """
        self.project = project
        self.results = []

    @property
    def df(self):
        """
        Convert results to DataFrame
        :return: pd.DataFrame
        """
        data = [{
            'clf': r['clf'],
            'score': r['score'],
            'flash': r['resources']['flash'],
            'flash_percent': r['resources']['flash_percent'],
            'memory': r['resources']['memory'],
            'memory_percent': r['resources']['memory_percent'],
            'flash_score': r['score'] * (1 - r['resources']['flash_percent']),
            'memory_score': r['score'] * (1 - r['resources']['memory_percent']),
        } for r in self.results]
        return pd.DataFrame(data, columns=['clf', 'score', 'flash', 'flash_percent', 'memory', 'memory_percent', 'flash_score', 'memory_score'])

    def benchmark(self, classifiers, X_test=None, y_test=None, X_train=None, y_train=None):
        """
        Benchmark given classifiers
        :param classifiers:
        :param X_train:
        :param y_train:
        :param classifier_name:
        :return: list of benchmark results
        """
        assert X_train is None and y_train is None or X_train is not None and y_train is not None, "X_train and y_train MUST both be None or not None"
        assert X_test is None and y_test is None or X_test is not None and y_test is not None, "X_test and y_test MUST both be None or not None"

        with self.project.tmp_project() as tmp:
            # benchmkark empty sketch
            tmp.files.add('%s.ino' % tmp.name, contents=jinja('metrics/Empty.jinja'), exists_ok=True)
            self.benchmark_one(tmp, 'No classifier')

            # load resources benchmarking sketch
            tmp.files.add('%s.ino' % tmp.name, contents=jinja('metrics/Resources.jinja'), exists_ok=True)

            for name, clf in classifiers:
                if X_train is not None:
                    clf.fit(X_train, y_train)

                ported = port(clf, classname='Classifier')
                tmp.files.add('Classifier.h', contents=ported, exists_ok=True)
                self.benchmark_one(tmp, name, clf, X_test, y_test)

        return self.results

    def benchmark_one(self, project, label, clf=None, X_test=None, y_test=None):
        """
        Benchmark a single classifier
        :param project:
        :param label:
        :param clf:
        :param X_test:
        :param y_test:
        :return:
        """
        compile_log = project.compile()

        self.results.append({
            'clf': label,
            'score': clf.score(X_test, y_test) if clf is not None and X_test is not None and y_test is not None else 0,
            'resources': self._parse_compile_log(compile_log)
        })

    def plot(self, metric, sort=True, **kwargs):
        """
        Plot given metric
        :param metric:
        :param sort:
        :return:
        """
        assert metric in self.df.columns and metric != 'clf', 'metric MUST be one of the columns'

        Barplot(self.df, x='clf', y=metric, sort=sort, **kwargs)

    def _parse_compile_log(self, compile_log):
        """
        Extract resource consumption from compilation output
        :param compile_log:
        :return: dict
        """
        flash_pattern = r'Sketch uses (\d+) bytes.+?Maximum is (\d+)'
        flash_match = re.search(flash_pattern, compile_log.replace("\n", ""))
        memory_pattern = r'Global variables use (\d+).+?Maximum is (\d+)'
        memory_match = re.search(memory_pattern, compile_log.replace("\n", ""))

        if flash_match is None and memory_match is None:
            raise RuntimeError('Cannot parse compilation log: %s' % compile_log)

        flash, flash_max = [int(g) for g in flash_match.groups()] if flash_match is not None else [0, 1]
        memory, memory_max = [int(g) for g in memory_match.groups()] if memory_match is not None else [0, 1]

        return {
            'flash': flash,
            'flash_max': flash_max,
            'flash_percent': float(flash) / flash_max,
            'memory': memory,
            'memory_max': memory_max,
            'memory_percent': float(memory) / memory_max,
        }
