from eloquentarduino.plot.spatial.TimeOfFlightVisualizer import TimeOfFlightVisualizer


def tof(*args, **kwargs):
    """
    Shortcut to TimeOfFlightVisualizer
    """
    return TimeOfFlightVisualizer(*args, **kwargs)